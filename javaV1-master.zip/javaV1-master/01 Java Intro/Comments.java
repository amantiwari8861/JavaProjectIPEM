public class Comments
{
    public static void main(String abc[])
    {
        // single line comment
        //System.out.println("Hello World 3");

        /* multiple line comment */

        /*
            System.out.println("Hello World 4");
            System.out.println("Hello World 4");
            System.out.println("Hello World 4");
            System.out.println("Hello World 4");
        */
    }
}