public class EscapeSequence 
{
    public static void main(String[] args) 
    {
        // System.out.println("Hello World 1");
        // System.out.println("Hello World 2");
        //here ln means new line (\n) in the end of msg

        // System.out.print("Hello");
        // System.out.print("Aman");
        // System.out.print("Sir");

        // System.out.print("\nHello\n");
        // System.out.print("Aman\n");
        // System.out.print("Sir\n");

        // System.out.print("Hello\t");
        // System.out.print("Aman\t");
        // System.out.print("Sir\n");

        System.out.printf("Hii i am %d printf ",56);
    }
}