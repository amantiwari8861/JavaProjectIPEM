// jdk -> java development kit 

//if a class is declared as public then FileName and classname must be same
public class HelloWorld
{
    public static void main(String[] abc) 
    {
        System.out.println("Hello World");
    }
}
//Note : S in String and System must be capital