class Ani
{
     int i = 10;
     static int j=20;
}
class staticvar{
    public static void main(String[] args) {
        
        // Ani a=new Ani();
        // System.out.println("Value of i is "+a.i);
        System.out.println("Value of j is "+Ani.j);

    }
}