class Immutable 
{
    public static void main(String[] args) 
    {
        String fname="Aman ";
        String lname=" Tiwari";
        // String fullname=fname.concat(lname);
        // System.out.println("the fullname is "+fullname);
        // or 
        System.out.println("the full name is :"+fname.concat(lname));//concatination
        // System.out.println(fname);


        // fname=fname.concat(lname);//re-initialization
        // System.out.println("the value of str1 is :"+fname);//Aman Tiwari

    }
}