public class ToStr {

    public static void main(String[] args) {
        
        // char arr[]={'a','m','a','n'};
        // String st=new String(arr);
        // System.out.println("the string is :"+arr.toString());
        // System.out.println("the string is :"+st);
        String str="Rohit";
        String arr[]=new String[7];
        System.out.println("the character is :"+str.charAt(2)); //h
        // what is the difference between length and length().
        System.out.println("the length of string is :"+str.length());
        // System.out.println(str.length); //error str is string
        System.out.println("the length of array is :"+arr.length);
    }
}