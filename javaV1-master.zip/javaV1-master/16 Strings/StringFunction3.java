public class StringFunction3 {
public static void main(String[] args) {
    
    // String objString="hello 50worlod";
    // int num=50;
    // // String number=num;
    // String number=String.valueOf(num);
    // System.out.println(objString.indexOf('o'));
    // System.out.println(objString.lastIndexOf('o'));
    // System.out.println(number+50);
    String name1="Aman";
    // String name2="Aasan";
    String name2="aman1h";
    System.out.println(name1.compareTo(name2));
    System.out.println(name1.compareToIgnoreCase(name2));
}
    
}