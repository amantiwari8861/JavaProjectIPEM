public class strarr {

    public static void main(String[] args) {
        
        char ch[]={'a','m','a','n'};
        String name=ch;
        // String str=new String(ch);
        // System.out.println(str);
        System.out.println(name);
       /* String name="aman";
        char n[]=name.toCharArray();

        for (char c : n) {
            System.out.println(c);
        }*/

      /*  String sname="Aman";
        String lname=" Tiwari";
        System.out.println(sname.concat(lname));
        System.out.println(sname); //string is immutable 
        sname=sname.concat(lname);// re-initialiation of sname string
        System.out.println(sname);

        String num1="10";
        String num2="20";

        int a=Integer.parseInt(num1);
        int b=Integer.parseInt(num2);
        System.out.println(num1+num2);
        System.out.println(a+b);

*/
}
}