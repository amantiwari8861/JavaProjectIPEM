class TestStr
{
    public static void main(String AA[])
    {
        String str1="Aman";
        String str2=str1+" Tiwari";
        String str3="Aman Tiwari";

        System.out.print(str2==str3);
    }
}