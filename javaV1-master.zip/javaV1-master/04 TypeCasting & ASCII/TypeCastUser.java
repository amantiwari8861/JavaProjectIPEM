import java.util.Scanner;

public class TypeCastUser {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);

        // byte num1,num2,result;
        // System.out.println("Enter the num1 and num2");
        // num1=sc.nextByte();
        // num2=sc.nextByte();
        // // result=num1+num2;//possible lossy conversion from int to byte
        // result=(byte) (num1+num2);
        // System.out.println("result ="+result);
        // System.out.println("sum is "+(num1+num2));

        // float f1,f2,res;
        // System.out.println("enter 2 values ");
        // f1=sc.nextFloat();
        // f2=sc.nextFloat();
        // res=f1+f2+56.8;//here 56.8 is double value
        // // res=(float)(f1+f2+56.8);
        // // res=f1+f2+56.8f;
        // System.out.println(" result :"+res);

        sc.close();
    }
}
