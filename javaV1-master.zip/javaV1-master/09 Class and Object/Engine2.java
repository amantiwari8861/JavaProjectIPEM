class Engine2
{
    void EngineFxn()
    {
        System.out.println("Engine is starting ");
    }
}