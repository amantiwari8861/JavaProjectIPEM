public class ClassName {
    public static void main(String[] args) {

        System.out.println("Hello World!");
    
    }
}
//to compile: javac FileName.java
//to run: java ClassName