public class DataType2 {
    public static void main(String[] args) {
        
        int num;
        num=10;
        int num2=100;
        int sum=num+num2;
        System.out.println("the value of num is :"+num);
        System.out.println(num2);
        System.out.println("the sum is :"+sum);
        
    }
}
