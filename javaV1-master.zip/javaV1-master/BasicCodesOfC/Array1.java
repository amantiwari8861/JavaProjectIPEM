import java.util.Scanner;

class Array1
{
    public static void main(String[] args) 
    {
        
    // int marks[4];
    // int marks[]=new int[3];

    // int marks[];
    // marks=new int[2];

    // marks[0]=101;
    // marks[1]=304;

    // System.out.println(marks[0]);
    // System.out.println(marks[1]);

    // marks=new int[4];
    // marks[0]=201;
    // marks[1]=202;
    // marks[2]=203;
    // marks[3]=204;

    // for (int i : marks) 
    // {
    //     System.out.println(i);
    // }

        //1. int marks[]=new int[4];
        //2. int marks;
        // marks=new int[4];
        // 3.
        //  int marks[]=new int[]{10,20,30,40};
        //4. int marks[]={100,200,300,400};

        // for (int i = 0; i < 4; i++) 
        // {
        //     System.out.println(marks[i]);
        // }

        // System.out.println("array's length is "+marks.length);

        // for (int i = 0; i < marks.length; i++) {
        //     System.out.println(marks[i]);
        // }

        // String names[]={"Aman 2.0","dolly","piyush","nimish","shivam","prince"};


        // // System.out.println(names[0]);

        // for (int i = 0; i < names.length; i++) {
        //     System.out.println(names[i]);
        // }

        // String Shirt[]=new String[4];
        // Scanner sc=new Scanner(System.in);
        // System.out.println("enter 4 shirts");
        // for (int i = 0; i < Shirt.length; i++) 
        // {
        //     Shirt[i]=sc.nextLine();
        // }
        // for (String sh : Shirt) {
        //     System.out.println("   "+sh);
        // }



    }
}