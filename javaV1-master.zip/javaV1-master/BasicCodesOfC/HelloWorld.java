class HelloWorld
{
    public static void main(String[] kuch_bhi) 
    {
        System.out.println("hiiii");
        System.out.println("Aman Tiwari 1.0");


        System.out.print("hello");
        System.out.print(" dolly");

        System.out.printf(" hello everyone %d \n",10);
        System.out.printf(" hello everyone %d ",10);


    }
}
