import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Locale;

class innerclass2
{
    // private int x=7;
    // public void makeinner() {
    //     in.seOuter();
    // }
    // class myinner
    // {
    //     public void seeouter() {
    //         int x=8;
    //         System.out.println("inner is "+x);
    //         System.out.println("outer is "+this.x);
    //     }
    // }


    public static void main(String[] args) {
        // innerclass2.myinner obj=new innerclass2().new myinner();
        // inner.seOuter();
//         try {
//             Files.createDirectories(Paths.get("C:/temp/a.txt"));
//         } catch (IOException e) {
// System.out.println("hii");        }

Locale frLocal
    }
}