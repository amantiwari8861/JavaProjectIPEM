class OuterClass
{
    //outer class
    //inner class
    //static inner class 
    //anonymous inner class
}
public class Run {
    public static void main(String[] args) {
        
        OuterClass obj=new OuterClass();
    }
}