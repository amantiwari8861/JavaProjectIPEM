public class Variables {
    public static void main(String[] args) {
        
        int a;//variable declaration
        a=55;//initialization of variable

        System.out.println("a");
        System.out.println(a);
        System.out.println("the value of a is "+a);
        System.out.println("a ki value "+a+" hai");

        int num,num2=56,num3=90,var1=98;

        System.out.println("num2 = "+num2+" num3="+num3+" var1="+var1);

    }
}
