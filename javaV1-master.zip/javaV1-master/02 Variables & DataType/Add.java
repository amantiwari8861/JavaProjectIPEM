public class Add 
{
    public static void main(String args[]) 
    {
        int a=12,b=23,c;
        c=a+b;

        System.out.println("the sum is ="+c);
        System.out.println("the sum of "+a+" and "+b+" is "+c);
    }
}