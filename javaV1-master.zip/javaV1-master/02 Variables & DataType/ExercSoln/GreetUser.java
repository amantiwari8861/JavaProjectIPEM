
public class GreetUser {

    public static void main(String[] args) {
        
    }
}