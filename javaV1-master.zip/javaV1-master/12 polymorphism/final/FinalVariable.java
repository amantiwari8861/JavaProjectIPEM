public class FinalVariable {

    public static void main(String[] args) {
        
        final float pi=3.14f;

        // pi=56.89f;


    }
}