final class Mule
{

}
class MuleChild extends Mule 
{

}
public class FinalClass 
{
    public static void main(String[] args) 
    {
        
    } 
}