public class FinalConstructor 
{
    // final FinalConstructor(){} //Illegal modifier for the constructor in type FinalConstructor; only public, protected & private are permitted
}