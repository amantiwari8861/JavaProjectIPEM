// this() and super()
import java.io.Console;  
class ReadStringTest{    
public static void main(String args[]){    
Console c=System.console();   
System.out.println("Enter your name: ");    
// String n=c.readLine();
// char[] ch=c.readPassword(); 
System.out.println("Welcome "+n);    
}    
}  
// public class Super4 {
//     public static void main(String[] args) {
        
//     }
// }
