class cla 
{
    public static void main(String data[])
    {
        String a1=data[0];
        String a2=data[1];
        String a3=data[2];
        String a4=data[3];
        String a5=data[4];
        System.out.println("at data[0] ="+a1);
        System.out.println("at data[1] ="+a2);
        System.out.println("at data[2] ="+a3);
        System.out.println("at data[3] ="+a4);
        System.out.println("at data[4] ="+a5);
    }
}