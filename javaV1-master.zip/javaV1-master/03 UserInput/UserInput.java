class  UserInput
{
    public static void main(String[] sanskaar) {
        
        //1. command line argument 
        //2. Scanner class
        String str1,str2,str3;
        str1=sanskaar[0];
        str2=sanskaar[1];
        // str3=sanskaar[2];
    System.out.println("the value is :"+str1);        
    System.out.println("the value is :"+str2);        
    // System.out.println("the value is :"+str3);        
    System.out.println(str1+str2);
    }
}