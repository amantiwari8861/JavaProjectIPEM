class cla3
{
    public static void main(String[] data) {

    // System.out.println(data[0]);
    // System.out.println(data[0].getClass().getName());

    // int a=Integer.parseInt(data[0]);
    // float f=Float.parseFloat(data[1]);
    // double d=Double.parseDouble(data[2]);
    // long l=Long.parseLong(data[3]);
    // byte b=Byte.parseByte(data[4]);
    // boolean bool=Boolean.parseBoolean(data[5]);
    // char ch=data[6].charAt(0);
    boolean ch2=Character.isUpperCase('B');
    System.out.println(ch2);
    // short s=Short.parseShort(data[7]);

    }
}