package PhilosopherProblem;

public enum State {
	LEFT, RIGHT;
}
