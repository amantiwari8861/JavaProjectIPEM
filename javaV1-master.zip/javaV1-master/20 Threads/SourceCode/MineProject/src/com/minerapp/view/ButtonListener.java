package com.minerapp.view;

public interface ButtonListener {
	public void startClicked();
	public void stopClicked();
}
