import java.awt.Frame;


class MyFrame extends Frame {

    
}


public class Frame1 {


    public static void main(String[] args) {
        
        Frame f=new Frame();
        f.setSize(300,200);//w*h
        f.setVisible(true);
    }

}