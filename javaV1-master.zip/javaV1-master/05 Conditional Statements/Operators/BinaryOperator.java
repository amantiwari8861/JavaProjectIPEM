public class BinaryOperator {

    public static void main(String[] args) {
     
        //Arithmatic Operator eg. +,-,*,/,% (Mod)

        // double num1=10,num2=3,result;

        // // result=num1+num2;
        // // result=num1-num2;
        // // result=num1*num2;
        // result=num1/num2;
        // // result=num1%num2; //for remainder (shesh)

        // System.out.println("Result is "+result);

        //Relational operator eg. <,>,<=,>=,==(equality),!= (inequality)

        // int n1=13,n2=13,res;
        // boolean result;

        // // res=n1<n2;// error : boolean cannot be converted to int
        // // result=n1<n2;
        // // result=n1>n2;
        // // result=n1<=n2;  //same as ≤ in math
        // // result=n1>=n2;
        // // result=n1==n2;
        // result=n1!=n2;

        // System.out.println(result);

        //Note: bitwise and logical will be in separate file

        //Assignment Operator eg. =,+=,-=,/=,*=,%=

        int v1=20;

        // v1+5; //error

        // v1=v1+5;
        //or
        v1+=5;

        System.out.println(v1);

    }
}