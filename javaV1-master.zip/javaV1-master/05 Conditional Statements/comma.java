public class comma {

    public static void main(String[] args) {
        
        int i=5,j=10;
        // System.out.printf("%d %d %d ",++i,++j,i+j);
        System.out.println((++i)+" "+(j++) +" "+(++j)+" "+(i++));
    }
}