import java.util.Arrays;
public class ArraysDemo {
    public static void main(String[] args) {
        
    // int arr[]=new int[5];
    int arr[]={10,20,30,40};
    // int arr[]=new int[]{10,20,40,60};
    // int arr[];
    // arr=new int[4];

    System.out.println();



    }
}
