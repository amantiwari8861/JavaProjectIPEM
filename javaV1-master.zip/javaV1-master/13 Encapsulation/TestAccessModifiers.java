import office.institute.Owner;

public class TestAccessModifiers 
{
    public static void main(String[] args) 
    {
        Owner insOwner=new Owner();
        insOwner.showTeacherDetails();
    }
}