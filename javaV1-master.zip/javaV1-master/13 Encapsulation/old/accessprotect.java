package demo.test;
import demo.test.protect1;
public class accessprotect {

    public static void main(String[] args) {
        protect1  obj=new protect1();
        obj.fxn();      
    }
}