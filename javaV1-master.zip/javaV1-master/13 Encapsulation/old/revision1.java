package rohit.rohan.aman;
public class revision1 {
    public void print() {
        System.out.println("hello world \n");
    }
    public static void main(String[] args) {
    //    revision1 obj;
        new revision1().print();

    }
}
//to compile : javac -d . revision1.java
//run: java rohit.rohan.aman.revision1

//this interfaces vs abstract
//scanner stringbuffer vs builder
// exception handling