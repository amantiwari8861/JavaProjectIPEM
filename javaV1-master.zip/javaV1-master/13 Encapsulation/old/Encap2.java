package com.java.abc;
import com.java.abc.*;
public class Encap2 {
public static void main(String[] args) {
    Encap obj=new Encap();
    obj.fxn();
	Encap4 obj2=new Encap4();
    obj2.fxn4();
}
}
// import com.java.aman.Encap;
// import com.java.aman.*;
