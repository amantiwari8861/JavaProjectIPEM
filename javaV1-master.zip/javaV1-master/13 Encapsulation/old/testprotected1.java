package p1;
class testprotected1
{
    public static void main(String[] args) {
        testprotected obj=new testprotected();
        obj.fxn();
        System.out.println(obj.i);
    }
}