package carfactory;
public class car1
{
    public void car1fxn()
    {
        System.out.println("hello i am car fxn");
    }
}