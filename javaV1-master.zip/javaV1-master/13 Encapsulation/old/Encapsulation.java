//wrapping data in a single unit 
//public private protected default
package demopackage.p1.p11.p111.p1111;
public class Encapsulation {
    public void print()
    {
        System.out.println("hello World22");
    }
    public static void main(String[] args) {
        System.out.println("hello World");
    }
}
//compile with javac -d . Encapsulation.java
//run with java demopackage.p1.p11.p111.p1111.Encapsulation
