package pack1;

class demo
{
    protected int i=50;
}

