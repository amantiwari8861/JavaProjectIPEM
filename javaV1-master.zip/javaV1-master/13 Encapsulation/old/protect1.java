package demo.test;

public class protect1 {

    protected void fxn() {
        System.out.println("hello i am protected method ");
    }
    
}