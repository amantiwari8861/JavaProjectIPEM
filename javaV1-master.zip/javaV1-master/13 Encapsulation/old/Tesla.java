// import carfactory.car1;
// import carfactory.car2;
// import carfactory.car3;
package carfactory;
import carfactory.*;

public class Tesla {
public static void main(String[] args) {
    car1 obj=new car1();
    car2 obj2=new car2();
    car3 obj3=new car3();
    obj.car1fxn();
    obj2.car2fxn();
    obj3.car3fxn();
}
}