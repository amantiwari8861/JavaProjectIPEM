import demopackage.p1.p11.p111.p1111.Encapsulation;//import single class 
// import demopackage.p1.p11.p111.p1111.*; //import all classes in folder
public class Encapsul {

    public static void main(String[] args) {
        System.out.println("hello Aman");
        Encapsulation obj=new Encapsulation();
        obj.print();
    }
}