package com.java.abc;
public class Encap {
public void fxn()
    {
        System.out.println("this is basic example of package ");
    }
}