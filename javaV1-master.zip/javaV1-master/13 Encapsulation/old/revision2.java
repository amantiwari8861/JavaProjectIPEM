package rohit.rohan.aman;

public class revision2 {


    public void print() {
        System.out.println("hello world 2.0 ");
    }
    public static void main(String[] args) {
        
        new revision2().print();

    }
}