// import rohit.rohan.aman.revision1;
// import rohit.rohan.aman.revision2;
// import java.lang.*; by default imported in out program
package rohit.rohan.aman;
import rohit.rohan.aman.*;

public class checkpackage {

    public static void main(String[] args) {
        
        revision1 obj=new revision1();
        obj.print();
        revision2 obj2=new revision2();
        obj2.print();
    }
}