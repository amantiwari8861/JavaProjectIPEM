package com.package2;

public class differentpack {

    protected void fxn() {
    // public void fxn() {
        System.out.println("hello i am protected method and accesed in sub class ");
    }
    
}