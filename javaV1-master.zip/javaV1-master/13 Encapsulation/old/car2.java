package carfactory;
public class car2
{
    public void car2fxn()
    {
        System.out.println("hello i am car 2 fxn");
    }
}