package com.pack1.pack11;
import com.package2.differentpack;

public class accessdiffpack {
public static void main(String[] args) {
    
    differentpack obj=new differentpack();
    obj.fxn();
}
    
}