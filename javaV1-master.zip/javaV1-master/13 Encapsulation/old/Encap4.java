package com.java.abc;
public class Encap4 {
public void fxn4()
    {
        System.out.println("this is basic example of package ");
    }
}