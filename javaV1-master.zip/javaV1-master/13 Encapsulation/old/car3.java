package carfactory;
public class car3
{
    public void car3fxn()
    {
        System.out.println("hello i am car 3 fxn");
    }
}