package test.pack1;

public class PackageTest 
{
    public static void main(String[] args) 
    {
        System.out.println("hello there");
    }
}
// to compile : javac -d . PackageTest.java
// -d means create directory
// . means same folder
// to run : java test.pack1.PackageTest